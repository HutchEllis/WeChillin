package com.example.projectthree;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class login extends AppCompatActivity {
    DatabaseHelper myDb;
    EditText editUsername, editPassword;
    Button btnLogin;
    TextView signupText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        myDb = new DatabaseHelper(this);

        editUsername = findViewById(R.id.username);
        editPassword = findViewById(R.id.password);
        btnLogin = findViewById(R.id.login_button);
        signupText = findViewById(R.id.signup_text);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();
                if (myDb.checkUser(username, password)) {
                    Toast.makeText(login.this, "Login successful", Toast.LENGTH_SHORT).show();
                    showEventsScreen(username);
                } else {
                    Toast.makeText(login.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        signupText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();
                if (myDb.addUser(username, password)) {
                    Toast.makeText(login.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(login.this, "Account creation failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showEventsScreen(String username) {
        setContentView(R.layout.events_screen);

        Button addButton = findViewById(R.id.addEventButton);
        LinearLayout eventsLayout = findViewById(R.id.eventsLayout);
        EditText nameEditText = findViewById(R.id.nameEditText);
        EditText dateEditText = findViewById(R.id.dateEditText);

        loadEvents(eventsLayout, username);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString();
                String date = dateEditText.getText().toString();
                if (!name.isEmpty() && !date.isEmpty() && date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                    if (myDb.addEvent(name, date, username)) {
                        addEventToLayout(eventsLayout, new Event(-1, name, date, username));
                        nameEditText.setText("");
                        dateEditText.setText("");
                    }
                }
            }
        });
    }

    private void loadEvents(LinearLayout eventsLayout, String username) {
        eventsLayout.removeAllViews();
        List<Event> events = myDb.getAllEvents(username);

        // Sort the events by date
        events.sort((e1, e2) -> e1.getDate().compareTo(e2.getDate()));

        // Clear existing views
        eventsLayout.removeAllViews();

        // Add the sorted events to the layout
        for (Event event : events) {
            if (event.getUsername().equals(username)){
            addEventToLayout(eventsLayout, event);
            }
        }
    }

    private void addEventToLayout(LinearLayout eventsLayout, Event event) {
        View eventView = getLayoutInflater().inflate(R.layout.event_item, null);
        TextView eventNameTextView = eventView.findViewById(R.id.eventNameTextView);
        TextView eventDateTextView = eventView.findViewById(R.id.eventDateTextView);
        eventNameTextView.setText(event.getName());
        eventDateTextView.setText(event.getDate());
        eventsLayout.addView(eventView);
    }
}


/*package com.example.projectthree;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class login extends AppCompatActivity {
    DatabaseHelper myDb;
    EditText editUsername, editPassword;
    Button btnLogin, btnSignup;
    TextView signupText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        myDb = new DatabaseHelper(this);

        editUsername = findViewById(R.id.username);
        editPassword = findViewById(R.id.password);
        btnLogin = findViewById(R.id.login_button);
        signupText = findViewById(R.id.signup_text);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();
                if (myDb.checkUser(username, password)) {
                    Toast.makeText(login.this, "Login successful", Toast.LENGTH_SHORT).show();
                    showEventsScreen();
                } else {
                    Toast.makeText(login.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        signupText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();
                if (myDb.addUser(username, password)) {
                    Toast.makeText(login.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(login.this, "Account creation failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showEventsScreen() {
        setContentView(R.layout.events_screen);

        Button addEventButton = findViewById(R.id.addEventButton);
        LinearLayout eventsLayout = findViewById(R.id.eventsLayout);
        EditText nameEditText = findViewById(R.id.nameEditText);
        EditText dateEditText = findViewById(R.id.dateEditText);

        loadEvents(eventsLayout);

        addEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString();
                String date = dateEditText.getText().toString();
                if (!name.isEmpty() && !date.isEmpty()) {
                    if (myDb.addEvent(name, date)) {
                        addEventToLayout(eventsLayout, new Event(-1, name, date));
                        nameEditText.setText("");
                        dateEditText.setText("");
                    }
                }
            }
        });
    }

    private void loadEvents(LinearLayout eventsLayout) {
        List<Event> events = myDb.getAllEvents();
        for (Event event : events) {
            addEventToLayout(eventsLayout, event);
        }
    }

    private void addEventToLayout(LinearLayout eventsLayout, Event event) {
        View eventView = getLayoutInflater().inflate(R.layout.event_item, null);
        TextView eventNameTextView = eventView.findViewById(R.id.eventNameTextView);
        TextView eventDateTextView = eventView.findViewById(R.id.eventDateTextView);
        eventNameTextView.setText(event.getName());
        eventDateTextView.setText(event.getDate());
        eventsLayout.addView(eventView);
    }
}*/


/*
package com.example.projectthree;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class login extends AppCompatActivity {
    DatabaseHelper myDb;
    EditText editUsername, editPassword;
    Button btnLogin, btnSignup;
    TextView signupText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        myDb = new DatabaseHelper(this);

        editUsername = findViewById(R.id.username);
        editPassword = findViewById(R.id.password);
        btnLogin = findViewById(R.id.login_button);
        signupText = findViewById(R.id.signup_text);



        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();
                if (myDb.checkUser(username, password)) {
                    Toast.makeText(login.this, "Login successful", Toast.LENGTH_SHORT).show();
                    //TODO: Add next part of app and send user there
                    Button addEventButton;
                    LinearLayout eventsLayout;
                    EditText nameEditText, dateEditText;
                    setContentView(R.layout.event_item);
                    addEventButton = findViewById(R.id.addEventButton);
                    eventsLayout = findViewById(R.id.eventsLayout);
                    nameEditText = findViewById(R.id.nameEditText);
                    dateEditText = findViewById(R.id.dateEditText);
                    addEventButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String name = nameEditText.getText().toString();
                            String date = dateEditText.getText().toString();
                            if (!name.isEmpty() && !date.isEmpty()) {
                                if (myDb.addEvent(name, date)) {
                                    //addEventToLayout(new Event(-1, name, date));
                                    nameEditText.setText("");
                                    dateEditText.setText("");
                                }
                            }
                        }
                    });

                } else {
                    Toast.makeText(login.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        signupText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();
                if (myDb.addUser(username, password)) {
                    Toast.makeText(login.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(login.this, "Account creation failed", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}



*/
