package com.example.projectthree;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "UserDB";
    private static final String TABLE_USERS = "Users";
    private static final String TABLE_EVENTS = "Events";
    private static final String COL_USER_ID = "ID";
    private static final String COL_USERNAME = "USERNAME";
    private static final String COL_PASSWORD = "PASSWORD";
    private static final String COL_EVENT_ID = "ID";
    private static final String COL_EVENT_NAME = "NAME";
    private static final String COL_EVENT_DATE = "DATE";
    private static final String COL_EVENT_USER = "USER";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT, PASSWORD TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_EVENTS + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, DATE TEXT, USER TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, contentValues);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE USERNAME=? AND PASSWORD=?", new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean addEvent(String name, String date, String user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_EVENT_NAME, name);
        contentValues.put(COL_EVENT_DATE, date);
        contentValues.put(COL_EVENT_USER, user);
        long result = db.insert(TABLE_EVENTS, null, contentValues);
        return result != -1;
    }

    public List<Event> getAllEvents(String username) {
        List<Event> eventList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_EVENTS + " ORDER BY " + COL_EVENT_DATE, null);
        if (cursor.moveToFirst()) {
            do {
                int columnIndex = cursor.getColumnIndex(COL_EVENT_ID);
                int id = cursor.getInt(columnIndex);
                columnIndex = cursor.getColumnIndex(COL_EVENT_NAME);
                String name = cursor.getString(columnIndex);
                columnIndex = cursor.getColumnIndex(COL_EVENT_DATE);
                String date = cursor.getString(columnIndex);
                eventList.add(new Event(id, name, date, username));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return eventList;
    }
}
